# jarvis_logic_ai_enhanced.py
# Enhanced version with multiple AI capabilities
import json
from pathlib import Path
from datetime import datetime

# ------------------ AI Model Imports ------------------
# Sentiment Analysis
SENTIMENT_AVAILABLE = False
try:
    from transformers import pipeline
    sentiment_analyzer = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")
    SENTIMENT_AVAILABLE = True
    print("✓ Sentiment Analysis loaded")
except Exception as e:
    print(f"⚠ Sentiment Analysis not available: {e}")

# Conversational AI with GPT4All
GPT4ALL_AVAILABLE = False
try:
    from gpt4all import GPT4All
    # Model will download automatically (~2-4GB)
    llm_model = GPT4All("Nous-Hermes-2-Mistral-7B-DPO.Q4_0.gguf")
    GPT4ALL_AVAILABLE = True
    print("✓ GPT4All conversational AI loaded")
except Exception as e:
    print(f"⚠ GPT4All not available: {e}")

# Question Answering
QA_AVAILABLE = False
try:
    from transformers import pipeline
    qa_model = pipeline("question-answering")
    QA_AVAILABLE = True
    print("✓ Question Answering loaded")
except Exception as e:
    print(f"⚠ Question Answering not available: {e}")

# Text Generation (lightweight)
TEXTGEN_AVAILABLE = False
try:
    from transformers import pipeline
    text_generator = pipeline("text-generation", model="distilgpt2")
    TEXTGEN_AVAILABLE = True
    print("✓ Text Generation loaded")
except Exception as e:
    print(f"⚠ Text Generation not available: {e}")

# ------------------ Memory Management ------------------
DATA_DIR = Path("jarvis_full_data")
DATA_DIR.mkdir(exist_ok=True)
LOG_FILE = DATA_DIR / "logic_memory.json"
CONTEXT_FILE = DATA_DIR / "conversation_context.json"

def load_memory():
    try:
        if LOG_FILE.exists():
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        print("Memory load error:", e)
    return []

def save_memory(memory):
    try:
        # Keep only last 100 entries
        memory = memory[-100:]
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            json.dump(memory, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print("Memory save error:", e)

def load_context():
    try:
        if CONTEXT_FILE.exists():
            with open(CONTEXT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except:
        pass
    return {"user_name": None, "preferences": {}, "last_topics": []}

def save_context(context):
    try:
        with open(CONTEXT_FILE, "w", encoding="utf-8") as f:
            json.dump(context, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print("Context save error:", e)

MEMORY = load_memory()
CONTEXT = load_context()

# ------------------ AI-Powered Decision Making ------------------
def decide_action(input_text):
    """
    Enhanced decision making with multiple AI models
    """
    input_lower = input_text.lower()
    response = "Sajnálom, nem értem pontosan."
    sentiment_data = None
    
    # 1. Analyze Sentiment
    if SENTIMENT_AVAILABLE:
        try:
            sentiment = sentiment_analyzer(input_text)[0]
            sentiment_data = sentiment
            print(f"🎭 Sentiment: {sentiment['label']} ({sentiment['score']:.2f})")
        except Exception as e:
            print(f"Sentiment analysis error: {e}")
    
    # 2. Check for greetings
    if any(word in input_lower for word in ["hello", "szia", "hi", "helló", "üdv"]):
        if CONTEXT.get("user_name"):
            response = f"Szia {CONTEXT['user_name']}! Miben segíthetek?"
        else:
            response = "Szia! Én vagyok Jarvis. Mi a neved?"
        
    # 3. Check for name introduction
    elif any(word in input_lower for word in ["nevem", "hívnak", "vagyok"]) and not CONTEXT.get("user_name"):
        # Extract name (simple approach)
        words = input_text.split()
        if len(words) > 1:
            potential_name = words[-1].strip(".,!?")
            CONTEXT["user_name"] = potential_name
            save_context(CONTEXT)
            response = f"Örülök a találkozásnak, {potential_name}! Hogy segíthetek ma?"
    
    # 4. Time request
    elif "idő" in input_lower or "óra" in input_lower:
        current_time = datetime.now().strftime('%H:%M:%S')
        response = f"A pontos idő: {current_time}"
    
    # 5. Date request
    elif "dátum" in input_lower or "nap" in input_lower:
        current_date = datetime.now().strftime('%Y-%m-%d')
        response = f"A mai dátum: {current_date}"
    
    # 6. Identity questions
    elif "ki vagy" in input_lower or "név" in input_lower:
        response = "Én vagyok Jarvis, egy mesterséges intelligencia asszisztens. Tony Stark után mintáztak, és itt vagyok, hogy segítsek neked!"
    
    # 7. 3D/Material related
    elif any(word in input_lower for word in ["3d", "modell", "anyag", "material"]):
        response = "Elindítom a 3D anyag generálást. Milyen anyagot szeretnél? (Titanium, Gold, Steel, Copper, Glass)"
    
    # 8. Question with GPT4All (most intelligent)
    elif GPT4ALL_AVAILABLE and ("?" in input_text or any(word in input_lower for word in ["miért", "hogyan", "mit", "ki", "hol", "mikor"])):
        try:
            print("🤖 Using GPT4All for intelligent response...")
            # Create context-aware prompt
            prompt = f"You are JARVIS, an AI assistant. User asked: {input_text}\nProvide a helpful, concise response in Hungarian:"
            llm_response = llm_model.generate(prompt, max_tokens=150, temp=0.7)
            response = llm_response.strip()
        except Exception as e:
            print(f"GPT4All error: {e}")
            response = "Gondolkodom a válaszon, de jelenleg kis nehézségeim vannak. Próbáld meg másképp megfogalmazni."
    
    # 9. Sentiment-based responses
    elif SENTIMENT_AVAILABLE and sentiment_data:
        if sentiment_data['label'] == 'NEGATIVE' and sentiment_data['score'] > 0.7:
            response = "Úgy tűnik, valami nem tetszik. Mesélj róla, hátha tudok segíteni!"
        elif sentiment_data['label'] == 'POSITIVE' and sentiment_data['score'] > 0.7:
            response = "Örülök, hogy jó a hangulatod! 😊 Miben segíthetek ma?"
    
    # 10. Context-aware fallback
    else:
        if GPT4ALL_AVAILABLE:
            try:
                # Use AI for general conversation
                prompt = f"You are JARVIS, Tony Stark's AI assistant. Respond naturally to: {input_text}\nKeep response concise and in Hungarian:"
                llm_response = llm_model.generate(prompt, max_tokens=100, temp=0.8)
                response = llm_response.strip()
            except Exception as e:
                print(f"GPT4All fallback error: {e}")
                response = "Érdekes kérdés! Próbáld meg részletesebben elmagyarázni."
        else:
            response = "Próbáld meg másképp megfogalmazni, vagy kérdezz konkrétabb dolgokat (idő, dátum, 3D modell, stb.)"
    
    # Save to memory with AI insights
    memory_entry = {
        "time": datetime.utcnow().isoformat(),
        "input": input_text,
        "response": response,
        "sentiment": sentiment_data,
        "ai_used": GPT4ALL_AVAILABLE or SENTIMENT_AVAILABLE
    }
    MEMORY.append(memory_entry)
    save_memory(MEMORY)
    
    # Update context
    CONTEXT["last_topics"].append(input_lower[:50])
    CONTEXT["last_topics"] = CONTEXT["last_topics"][-5:]  # Keep last 5 topics
    save_context(CONTEXT)
    
    return response

# ------------------ Scene Analysis (Enhanced) ------------------
def analyze_scene(scene_data=None):
    """
    Enhanced scene analysis with AI capabilities
    """
    analysis = {
        "objects_detected": [],
        "threat_level": 0,
        "confidence_scores": [],
        "description": ""
    }
    
    if scene_data:
        objects = scene_data.get("objects", [])
        analysis["objects_detected"] = objects
        
        # Calculate threat level based on objects
        dangerous_objects = ["knife", "gun", "fire", "weapon"]
        threat_count = sum(1 for obj in objects if any(danger in obj.lower() for danger in dangerous_objects))
        analysis["threat_level"] = min(threat_count * 3, 10)  # 0-10 scale
        
        # Generate description with AI if available
        if TEXTGEN_AVAILABLE and objects:
            try:
                prompt = f"Describe scene with: {', '.join(objects[:5])}"
                description = text_generator(prompt, max_length=50, num_return_sequences=1)[0]['generated_text']
                analysis["description"] = description
            except:
                analysis["description"] = f"Scene contains: {', '.join(objects[:5])}"
        else:
            analysis["description"] = f"Detected {len(objects)} objects"
    
    return analysis

# ------------------ Get AI Status ------------------
def get_ai_status():
    """
    Returns which AI models are currently available
    """
    return {
        "sentiment_analysis": SENTIMENT_AVAILABLE,
        "conversational_ai": GPT4ALL_AVAILABLE,
        "question_answering": QA_AVAILABLE,
        "text_generation": TEXTGEN_AVAILABLE,
        "ai_enhanced": any([SENTIMENT_AVAILABLE, GPT4ALL_AVAILABLE, QA_AVAILABLE, TEXTGEN_AVAILABLE])
    }

# ------------------ Test Code ------------------
if __name__ == "__main__":
    print("\n" + "="*50)
    print("JARVIS AI Enhanced Logic Test")
    print("="*50 + "\n")
    
    # Show AI status
    status = get_ai_status()
    print("AI Models Status:")
    for model, available in status.items():
        print(f"  {'✓' if available else '✗'} {model}")
    print()
    
    # Test conversations
    test_inputs = [
        "Szia Jarvis!",
        "Nevem Peter",
        "Hány óra van?",
        "Mi a mai dátum?",
        "Ki vagy te?",
        "Generálj egy titanium anyagot",
        "Miért kék az ég?",
        "Ma nagyon rossz napom van",
        "Örülök, hogy itt vagy!"
    ]
    
    for user_input in test_inputs:
        print(f"\n👤 User: {user_input}")
        response = decide_action(user_input)
        print(f"🤖 Jarvis: {response}")
        print("-" * 50)