# jarvis_vision.py
import cv2
import threading

# ------------------ YOLO import ------------------
YOLO_AVAILABLE = False
try:
    from ultralytics import YOLO
    YOLO_AVAILABLE = True
except Exception:
    print("YOLO import hiba! Objektumfelismerés offline nem működik.")

# ------------------ Objektumfelismerés elindítása ------------------
def start_vision():
    if not YOLO_AVAILABLE:
        print("YOLO nem elérhető, a kamera modul nem indul.")
        return

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Kamera nem elérhető!")
        return

    try:
        YOLO
        detector = YOLO("models/yolov11n.pt")  # YOLO modell betöltése
    except Exception as e:
        print("YOLO modell betöltési hiba:", e)
        return

    print("Kamera modul elindult. Objektumfelismerés folyamatban...")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Kamera olvasási hiba!")
            break

        # YOLO feldolgozás
        try:
            results = detector(frame)
            for result in results:
                boxes = result.boxes.xyxy
                for box in boxes:
                    x1, y1, x2, y2 = [int(v) for v in box]
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0,255,0), 2)
        except Exception as e:
            print("YOLO feldolgozási hiba:", e)

        # Kép megjelenítése
        cv2.imshow("Jarvis Kamera", frame)

        # Kilépés ESC gombbal
        if cv2.waitKey(1) & 0xFF == 27:
            break

    cap.release()
    cv2.destroyAllWindows()
    print("Kamera modul leállt.")
